#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys

from . import info
from . import main

def run():
	main.main()